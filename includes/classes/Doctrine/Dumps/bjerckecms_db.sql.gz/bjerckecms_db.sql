-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: bjerckecms
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `author_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `background_image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_background` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_BFDD3168F675F31B` (`author_id`),
  CONSTRAINT `FK_BFDD3168F675F31B` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,1,'Lorem ipsum','<p><span id=\"isPasted\" style=\'color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span></p>','1652179275',NULL,0),(2,1,'Itaque earum','<p><span id=\"isPasted\" style=\'color: rgb(0, 0, 0); font-family: \"Open Sans\", Arial, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: justify; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\'>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</span></p>','1652179317',NULL,0),(22,1,'Marius Toresen Bjercke','<p>IT-student hos GET Academy der jeg for &oslash;yeblikket l&aelig;rer meg C#, ASP.NET, SQL, HTML, CSS, JavaScript, Vue.js og Node.js. Har noe tidligere erfaring med PHP. Ved siden av programmeringsspr&aring;k s&aring; l&aelig;rer vi om diverse n&oslash;kkelkompetanser der growth mindset st&aring;r i sterk fokus.</p>','1652355508','627cf1b4309036.38421831.png',1);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_posts`
--

DROP TABLE IF EXISTS `forum_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `author_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_90291C2DF675F31B` (`author_id`),
  CONSTRAINT `FK_90291C2DF675F31B` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_posts`
--

LOCK TABLES `forum_posts` WRITE;
/*!40000 ALTER TABLE `forum_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_strings`
--

DROP TABLE IF EXISTS `language_strings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language_strings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci DEFAULT NULL,
  `no` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `en` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_strings`
--

LOCK TABLES `language_strings` WRITE;
/*!40000 ALTER TABLE `language_strings` DISABLE KEYS */;
INSERT INTO `language_strings` VALUES (1,'not_signed_in','Du er ikke logget inn.','You are not signed in.'),(2,'login','Logg inn','Login'),(3,'register','Registrer deg','Register'),(4,'username','Brukernavn','Username'),(5,'password','Passord','Password'),(6,'welcome_to_forum','Velkommen til forumet.','Welcome to the forum.'),(7,'discuss_with_others','Her kan du diskutere forskjellige temaer med andre medlemmer.','Here you can discuss various topics with other users.'),(8,'latest_posts','Siste innlegg','Latest posts'),(9,'no_posts','Ingen innlegg enda.','No posts yet.'),(10,'forum','Forum','Forum'),(11,'new_post','Nytt innlegg','New post'),(12,'submit','Send','Submit'),(13,'close','Lukk','Close'),(14,'title','Tittel','Title'),(15,'type_something','Skriv noe','Type something'),(16,'logout','Logg ut','Logout'),(17,'home','Hjem','Home'),(18,'login','Logg inn','Login'),(19,'register','Registrer','Register'),(20,'forum','Forum','Forum'),(21,'profile','Profil','Profile'),(22,'admin','Admin','Admin'),(23,'pagebuilder','Sidebygger','Page Builder'),(24,NULL,'Velkommen til Bjercke CMS.','Welcome to Bjercke CMS.'),(25,NULL,'Logg inn på din brukerkonto.','Log in to your user account.'),(26,NULL,'Registrer deg for å få tilgang til vårt innhold.','Register to access our content.'),(27,NULL,'Kommuniser med andre medlemmer via forumet.','Communicate with other members in our forum.'),(28,NULL,'Administrasjonsside.','Administration page.'),(29,NULL,'Modifiser undersidene på nettsiden med sidebyggeren.','Modify the site pages with the page builder.'),(30,NULL,'Profilside.','User profile page.'),(31,'use_background_image','Bruk bakgrunnsbilde?','Use a background image?'),(32,'new_article','Ny artikkel','New article'),(33,'administer_articles','Endre artikler','Edit articles'),(34,'administer_tiles','Endre brikker','Edit tiles'),(35,'add_tile','Legg til ny brikke','Add new tile'),(36,'template_path','Mal sti','Template path'),(37,'choose','Velg','Choose'),(38,'administration','Administrasjon','Administration'),(39,'class_name','Klasse navn','Class name'),(40,NULL,'Eksempel: ArticleDisplay (i namespace Bjercke\\Tile)','Example: ArticleDisplay (in namespace Bjercke\\Tile)'),(41,'save','Lagre','Save'),(42,NULL,'Eksempel: Tiles/Articles/Display/articledisplay.html.twig','Example: Tiles/Articles/Display/articledisplay.html.twig'),(43,'existing_tiles','Eksisterende brikker','Existing tiles'),(44,'class','Klasse','Class'),(45,'edit_articles','Endre artikler','Edit articles'),(46,'edit_article','Endre artikkel','Edit article'),(47,'go_back','Gå tilbake','Go back'),(48,'canvas','Canvas','Canvas');
/*!40000 ALTER TABLE `language_strings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `tile_class` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `navigation` tinyint(1) NOT NULL,
  `requires_login` tinyint(1) NOT NULL DEFAULT '0',
  `hide_when_logged_in` tinyint(1) NOT NULL,
  `tile_order` longtext CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci COMMENT '(DC2Type:simple_array)',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Home','17','24','default','home','Home/home.html.twig','Home',1,0,0,'18',1),(2,'Login','18','25','default','login','Login/login.html.twig','Login',1,0,1,'',1),(3,'Register','19','26','default','register','Register/register.html.twig','Register',1,0,1,NULL,1),(4,'Forum','20','27','default','forum','Forum/forum.html.twig','Forum',1,0,0,NULL,0),(5,'Profile','21','30','default','profile','Profile/profile.html.twig','Profile',1,1,0,'11',1),(6,'Admin','22','28','default','admin','Admin/admin.html.twig','Admin',1,1,0,NULL,0),(7,'PageBuilder','23','29','default','pagebuilder','PageBuilder/pagebuilder.html.twig','PageBuilder',1,1,0,NULL,0),(8,'EditArticles','45','45','default','editarticles','Admin/EditArticles/editarticles.html.twig','EditArticles',0,1,0,NULL,0),(9,'EditArticle','46','46','default','editarticle','Admin/EditArticle/editarticle.html.twig','EditArticle',0,1,0,NULL,0),(10,'Canvas','48','48','default','canvas','Canvas/canvas.html.twig','CanvasPage',0,0,0,'21',1);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiles`
--

DROP TABLE IF EXISTS `tiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `template_path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `class_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `options` json NOT NULL,
  `article_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1C1584BB7294869C` (`article_id`),
  CONSTRAINT `FK_1C1584BB7294869C` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiles`
--

LOCK TABLES `tiles` WRITE;
/*!40000 ALTER TABLE `tiles` DISABLE KEYS */;
INSERT INTO `tiles` VALUES (10,'New Tile','Tiles/Tools/NewTile/newtile.html.twig','NewTileTile','null',NULL),(11,'New Page','Tiles/Tools/NewPage/newpage.html.twig','NewPageTile','null',NULL),(12,'Page Builder','Pages/PageBuilder/builder.html.twig','PageBuilder','null',1),(15,'Single Billboard','Tiles/Billboards/Single/singlebillboard.html.twig','SingleBillboardTile','null',1),(16,'Edit Tile','Pages/PageBuilder/edit.html.twig','PageBuilderTile','[]',NULL),(17,'New Article','Tiles/Articles/New/newarticle.html.twig','NewArticleTile','[]',NULL),(18,'Front Page Top Billboard','Tiles/Billboards/Single/singlebillboard.html.twig','SingleBillboardTile','[]',22),(21,'Canvas','Tiles/Fun/Canvas/canvas.html.twig','CanvasTile','[]',NULL);
/*!40000 ALTER TABLE `tiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci NOT NULL,
  `logged_in` tinyint(1) NOT NULL DEFAULT '0',
  `addon_level` int DEFAULT NULL,
  `account_level` int DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `last_activity` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'demo','demo','demo@demo.com',1,2,3,0,'1652450122'),(3,'admin','admin','admin@admin.com',0,2,3,0,'1652172620');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-25 14:35:51
